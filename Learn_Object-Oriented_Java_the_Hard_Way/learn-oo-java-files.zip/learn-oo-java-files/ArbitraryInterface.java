public interface ArbitraryInterface {
	public double getNumber();
	public void doSomething(int n);
}
