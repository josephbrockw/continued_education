// DOES NOT COMPILE
public class InterfaceDisappointment implements ArbitraryInterface {
	public void doSomething(double n) {
		System.out.println(n);
	}
}
