public interface Locatable {
	Location getLocation();
}
