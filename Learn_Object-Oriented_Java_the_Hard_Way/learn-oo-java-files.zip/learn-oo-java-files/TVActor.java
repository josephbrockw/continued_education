public class TVActor {
	String name;
	String role;
}
