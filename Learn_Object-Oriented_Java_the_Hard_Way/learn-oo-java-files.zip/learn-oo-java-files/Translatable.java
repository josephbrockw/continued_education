public interface Translatable {
	public void translate(int dx, int dy);
}
