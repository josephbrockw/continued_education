import zoo.Horse;
import zoo.Llama;

public class ZooDriver {
	public static void main( String[] args ) {
		Horse bj = new Horse();
		Llama kuz = new Llama();

		System.out.println( bj );
		System.out.println( kuz );
	}
}
